function populate() {
    if(quiz.isEnded()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;

        // show options
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i < choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess("btn" + i, choices[i]);
        }

        showProgress();
    }
};

function guess(id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        quiz.guess(guess);
        populate();
    }
};


function showProgress() {
    var currentQuestionNumber = quiz.questionIndex + 1;
    var element = document.getElementById("progress");
    element.innerHTML = "Question " + currentQuestionNumber + " of " + quiz.questions.length;
};

function showScores() {
    var gameOverHTML = "<h1>Result</h1>";
    gameOverHTML += "<h2 id='score'> Your scores: " + quiz.score + "</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHTML;
};

// create questions
var questions = [
    new Question("Which of the 4 options is a convolution filter?", ["Triangle Filter ", "Curved Filter","Tent Filter", "Discrete Filter"], "Tent Filter"),
    new Question("The Box fitler has both ______ & ______ filters.", ["Discrete & Continuous", "Linear & Discrete", "Continuous & Linear", "Exponential & Linear"], "Discrete & Continuous"),
    new Question("Changing the sample rate or size is called", ["upsampling", "resampling","downsampling", "undersampling"], "resampling"),
    new Question("What does DAC stand for?", ["Digital to Audio Converter", "Digital to Analog Converter", "Digital to Amazing converter", "All"], "Digital to Analog Converter"),
    new Question("An Analog to Digital converter can...", ["measure voltage", "produce voltage", "reconstruct voltage", "All"], "measure voltage"),
	new Question("Convolution takes two functions and ______ them together to produce a new function.", ["combines", "adds", "multiplies", "dot product"], "combines"),
	new Question("Convolution is a ______ operation.", ["associative", "commutative", "distibutive", "all"], "all"),
	new Question("Moire patterns emerge from ______.", ["improper sampling", "upsampling", "not enough sampling", "floating point numbers"], "improper sampling"),
	new Question("What type of filter does 00001110000 represent?", ["Box filter", "Tent filter", "Gaussian filter", "B-Spline cubic"], "measure voltage"),
	new Question("Convolution is important because we can use it to perform ______.", ["sampling", "filtering", "reconstructions", "All"], "filtering")
];

// create quiz
var quiz = new Quiz(questions);

// display quiz
populate();





